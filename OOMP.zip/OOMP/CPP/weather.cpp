#include<iostream.h>
#include<conio.h>

class WeatherReport
	{
	int entries,day_of_month[99],hightemp[99],lowtemp[99],amtrain[99],amtsnow[99];
	public:
	WeatherReport()
		{
		for(int i=1;i<100;i++)
			{
		day_of_month[i]=99;
		hightemp[i]=999;
		lowtemp[i]=-999;
		amtrain[i],amtsnow[i]=0;
			}
		}

	void create()
		{

		cout<<"enter the no of enteries for the month"<<endl;
		cin>>entries;
		cout<<"DAY \t high temp \t low temp \ amtrain \t amtsnow \n";
		for(int i=1;i<=entries;i++)
			{
			cout<<i<<"\t";
			cin>>hightemp[i]>>lowtemp[i]>>amtrain[i]>>amtsnow[i];
			}
		}
	void override()
		{
		int i;
		cout<<"enter the day of month"<<endl;
		cin>>i;
		cout<<"enter the values : High temp, low temp, amount of rain and amount of snow"<<endl;
		cin>>hightemp[i]>>lowtemp[i]>>amtrain[i]>>amtsnow[i];
		}

       void display()
		{
		cout<<"DAY \t high temp \t low temp \ amtrain \t amtsnow \n";
		for(int i =1;i<100;i++)
			{
			cout<<i<<"\t"<<hightemp[i]<<"\t\t"<<lowtemp[i]<<"\t\t"<<amtrain[i]<<"\t\t"<<amtsnow[i]<<endl;
			}
		}
       void average()
		{
		float ahtemp=0, altemp, aarain, aasnow=0;
		for(int i=1;i<=entries;i++)
			{
			ahtemp=ahtemp+hightemp[i];
			altemp=altemp+lowtemp[i];
			aarain=aarain+amtrain[i];
			aasnow=aasnow+amtsnow[i];
			}
		ahtemp=ahtemp/entries;
		altemp=altemp/entries;
		aasnow=aasnow/entries;
		aarain=aarain/entries;
		cout<<"average: "<<ahtemp<<"\t"<<altemp<<"\t"<<aarain<<"\t"<<aasnow<<endl;
		}
};
       int main()
		{
		clrscr();
		WeatherReport o;
		int ch,cont;
		do
			{
			cout<<"1:Create\n2:Overide\n 3:diplay\n 4:Average\n";
			cin>>ch;
			switch(ch)
				{
				case 1:
				o.create();
				break;
				case 2:
				o.override();
				break;
				case 3:
				o.display();
				break;
				case 4:
				o.average();
				break;
				default:
				cout<<"invalid choice\n";
				break;
				}
			cout<<"do you want to continue?\n 1:yes 0:no \n";
			cin>>cont;
			}while(cont==1);


		return 0;
		}
