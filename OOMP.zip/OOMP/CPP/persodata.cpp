#include<iostream>
#include<string.h>
using namespace std;
static int c;
class data
{
char name[20],bld[5],date1[15],ins[15],con[20],tel[15],lin[20];
float ht,wt;
public:
friend void getdata( data &i);
data()
{
strcpy(name,"NAME");
strcpy(bld,"BLD");
strcpy(ins,"INS");
strcpy(con,"CON");
strcpy(tel,"TEL");
strcpy(lin,"LIN");
ht=0;
wt=0;
strcpy(date1,"00-00-0000");
}
data(data &i)
{
strcpy(name,i.name);
strcpy(bld,i.bld);
strcpy(date1,i.date1);
strcpy(ins,i.ins);
strcpy(con,i.con);
strcpy(tel,i.tel);
strcpy(lin,i.lin);
ht=i.ht;
wt=i.wt;
}
data(char a[],char b[],char c[],char d[],char e[],char f[],char g[],float h,float w)
{
strcpy(name,a);
strcpy(bld,b);
strcpy(date1,c);
strcpy(ins,d);
strcpy(con,e);
strcpy(tel,f);
strcpy(lin,g);
ht=h;
wt=w;
}


static void count()
{
cout<<"\n Total no of persons are:"<<c;
}
void display()
{
cout<<"\nName\tBlod_gr\tHeigh\tWeigh\tIns_n\tCo_Add\tTel\tLic_no\tDa_of_Birth";
cout<<"\n"<<name<<"\t"<<bld<<"\t"<<ht<<"\t"<<wt<<"\t"<<ins<<"\t"<<con<<"\t"<<tel<<"\t"<< lin<<"\t"<<date1;
}
~data()
{
}
};
void getdata(data &i)
{
cout<<"\n Enter the name:";
cin>>i.name;
cout<<"\n Enter the Date of birth:";
cin>>i.date1;
cout<<"\n Enter the Blood group:";
cin>>i.bld;
cout<<"\n Enter the height:";
cin>>i.ht;
cout<<"\n Enter the weight:";
cin>>i.wt;
cout<<"\n Enter the insurance policy no:";
cin>>i.ins;
cout<<"\n Enter the contact address:";
cin>>i.con;
cout<<"\n Enter the telephone no:";
cin>>i.tel;
cout<<"\n Enter the license no:";
cin>>i.lin;
c++;
}

int main()
{
int n,i,w,v=1;
data d[20],d1;
data m("Arti","b+ve","12.1.2014","123424","1234","4243","0000",156,45);
data b(m);
cout<<"\n\n\t\t OUTPUT\n";
do
{
cout<<"\n Enter the choice:\n1.Use of constructor\n2.Create\n3.Use of static variable\n4.Display\n5.Exit.";
cin>>n;
switch(n)
{
case 1:
	cout<<"\n Enter the choice:\n1.Default constructor\n2.Parameterised\n3.Copy constructor.";
	cin>>w;
	switch(w)
	{
	case 1:
		 cout<<"\n\t\tDefault constructor:\n\n";
		 d1.display();
		 break;
	case 2:
		cout<<"\n\t\tparameterized constructor:\n\n";
		m.display();
		break;
	case 3:
		cout<<"\n\t\tcopy constuctor:\n\n";
	   		b.display();
		break;
	}
	break;
case 2:i=0;
	while(v==1)
	{
	
	getdata(d[i]);
	i++;
	cout<<"\n Enter 1 if you want to continue:";
	cin>>v; 
	}
	break;
case 3:	data::count();
	break;
case 4:
	for(v=0;v<i;v++)
	{
	d[v].display();
	}
	break;
}
}while(n!=5);
return 0;
}





