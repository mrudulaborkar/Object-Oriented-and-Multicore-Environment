import java.util.*;

class Sort<T extends Number>{
	Scanner s = new Scanner(System.in);
	T arr[];
	int a;
	public Sort(T arr[]){
		this.arr = arr;
	}
	public void bubbleSort(){
		T temp;
		 for(int j =1; j<arr.length; j++){
	            for(int i = 0; i < (arr.length - j); i ++){
	                if((((Comparable)(arr[i])).compareTo(arr[i+1])) > 0){
	                    temp = arr[i];
	                    arr[i] = arr[i + 1];
	                    arr[i + 1] = temp;
	                }               
	            }
	        }
		//System.out.println("Sorted array is :" +arr);
		 System.out.println("Sorted array is : [ ");
		 for(int i=0;i<arr.length;i++){
			 System.out.println(arr[i] + " ");
		 }
		 System.out.println(" ]");
	}
}

public class B6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in); 
		int i,a;
		Integer iarr[];
		Float farr[];
		char ch = 0;
		do{
			System.out.println("\n1.Sort For integer.\n2.Sort for float.\n3.Exit.\nEnter your choice:");
			i = s.nextInt();
			switch (i) {
			case 1:
				System.out.println("How many integer numbers you want to add:");
				a = s.nextInt();
				iarr = new Integer[a];
				for(int j=0;j<a;j++){
					System.out.println("Enter " +(j+1)+ "th number:");
					iarr[j] = s.nextInt();
				}
				Sort<Integer> sr = new Sort<Integer>(iarr);
				sr.bubbleSort();
				break;
				
			case 2:
				System.out.println("How many float numbers you want to add:");
				a = s.nextInt();
				farr = new Float[a];
				for(int j=0;j<a;j++){
					System.out.println("Enter " +(j+1)+ "th number:");
					farr[j] = s.nextFloat();
				}
				Sort<Float> sr1 = new Sort<Float>(farr);
				sr1.bubbleSort();
				break;

			default:
				System.out.println("Invalid choice..!");
				break;
			}
			System.out.println("Do you want to sort again:");
			ch = s.next().charAt(0);
		}while(ch=='y');
	}
}