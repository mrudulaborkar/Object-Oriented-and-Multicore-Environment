#include<iostream>
using namespace std;
#include<stdlib.h>

class shape
{
      public:
	double width,height,area;     	
	friend void getdata();
	double calr(){
	double a = width*height;
	return a;
	}
	double calt(){
	double a = width*height*0.5;
	return a;
	}
}s;

class rectangle:public shape
{
  public:
   friend void getdata();
   /*double calr()
     {
	double a = width*height ;
        return(a);
     }*/ 
}r;

class triangle:public shape
{
   public:
  friend void getdata();
     /*double calt()
     {
	double a = width*height*0.5;
      return(a);
     }*/
}t;

void getdata(){
	double num1,num2;
	cout<<"Enter length:";
	cin>>num1;
	cout<<"Enter breadth:";
	cin>>num2;
	t.width=num1;
	r.width=num1;
	t.height=num2;
	r.height=num2;	
}

int main()
{
	//shape s;
	getdata();
  	s = r;
	double area;
	area = s.calr();
	cout<<"\nArea of ractangle is:"<<area;
	s = t;
	area = s.calt();
	cout<<"\nArea of triangle:"<<area<<"\n";
	return 0;
}



OUTPUT:
[user@localhost OOMPSE]$ g++ shape.cpp
[user@localhost OOMPSE]$ ./a.out
Enter length:10
Enter breadth:10

Area of ractangle is:100
Area of triangle:50
[user@localhost OOMPSE]$ 



