#include<iostream>
using namespace std;

class television
{
    int model_no;
    int screen_size;
    int price;

public:
    void init()
    {
        model_no=screen_size=price=0;
    }

    friend istream &operator>>(istream &i,television &t)
    {
        cout<<"Enter the Model number : ";
        cin>>t.model_no;
        cout<<"Enter the Screen size : ";
        cin>>t.screen_size;
        cout<<"Enter the Price : ";
        cin>>t.price;

        try{
        if(t.model_no>9999)
            throw(1);
        if(t.screen_size<12 || t.screen_size>70)
            throw(2);
        if(t.price<0 || t.price>5000)
            throw(3);
        }

        catch(int x)
        {
            if(x==1)
                cout<<"\nInvalid Model Number\n";
            if(x==2)
                cout<<"\nInvalid Screen Size\n";
            if(x==3)
                cout<<"\nInvalid Price\n";
            t.init();
        }
    }

    friend ostream &operator<<(ostream &o,television &t)
    {
        cout<<"\nModel No\t Screen size\t Price\n";
        cout<<t.model_no<<"\t"<<"\t"<<t.screen_size<<"\t"<<"\t"<<t.price;
    }
};
int main()
{
    television t1;
    cin>>t1;
    cout<<t1;
    return 0;
}
