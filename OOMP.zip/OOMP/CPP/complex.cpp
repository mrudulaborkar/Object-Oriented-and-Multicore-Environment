#include<iostream>
using namespace std;
#include<stdlib.h>

  class complex
  {
	  float real;
	  float img;
		 public:
			 complex()
				{
					real=img=0;
				}

			 complex(float a,float b)
			  {
				  real=a;
				  img=b;
			  }

			  void display()
			  {
				 cout<<real<<" + i"<<img;
			  }

			  complex operator +(complex);
			  complex operator -(complex);
			  complex operator *(complex);
			  complex operator /(complex);
	};

	complex complex::operator +(complex c)
	 {
		complex t;
		 t.real=real+c.real;
		 t.img=img+c.img;
		 return(t);
	  }

	complex complex::operator -(complex c)
	 {
		 complex tm;
		  tm.real=real-c.real;
		  tm.img=img-c.img;
		  return(tm);
	  }

	complex complex::operator *(complex c)
	 {
		 complex c3;
		 c3.real=(real*c.real)-(img*c.img);
		 c3.img=(real*c.img)-(img*c.real);
		 return(c3);
	 }

	complex complex::operator /(complex c)
	 {
		 complex c3;
		 float den;
		  den=(c.real*c.real)-(c.img*c.img);
		  c.img=c.img*(-1);
		  c3.real=real*c.real-img*c.img;
		  c3.img=real*c.img+img*c.real;
		  c3.real/den;
		  c3.img/den;
		  return(c3);
	  }

 int main()
  {
	 int m;
	 char n;
	 complex c1(2.4,3.4);
	 complex c2(4.6,6.7);
	 complex c3,c4,c5,c6;
	 cout<<"\n Given two complex numbers:\n";
	 c1.display();
         cout<<"\n";
	 c2.display();

		do
		 { cout<<"\n";
			cout<<"\n \t \t Menu"<<"\n";
			cout<<"\n 1.Addition \n 2.Subtraction \n 3.Multiplication \n 4.Division \n 5.Exit"<<"\n";
			cout<<"enter ur choice:";
			cin>>m;


			switch(m)
			 {
				case 1:cout<<"\t \t Addition of Complex Numbers"<<"\n";
						 c3=c1+c2;
						 cout<<"c3=";
						 c3.display();
						 break;

				case 2:cout<<"\t \t Subtraction of Complex Numbers"<<"\n";
						 c4=c1-c2;
						 cout<<"c4=";
						 c4.display();
						 break;

				case 3:cout<<"\t \t Multiplication of Complex Numbers"<<"\n";
						 c5=c1*c2;
						 cout<<"c5=";
						 c5.display();
						 break;

				case 4:cout<<"\t \t Division of Complex Numbers"<<"\n";
						 c6=c1+c2;
						 cout<<"c6=";
						 c6.display();
						 break;

				case 5:
						  exit(0);

				default:
							cout<<"\n You Entered wrong choice!!!";
							break;

		  }
	  }while(n!=4);

  return 0;
 }

