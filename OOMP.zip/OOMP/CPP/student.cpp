#include<iostream>
using namespace std;

class studentinfo
{
	protected:
	char name[20],sub[20];
	int roll;
};

class marks:public virtual studentinfo
{
	int code,ia,um;
	public:
	void getdata();
	void displaydata();
	void modify();
	int search(int key);
};

void marks::getdata()
{
	cout<<"enter the name of student:";
	cin>>name;
	cout<<"enter the subject:";
	cin>>sub;
	cout<<"enter the roll no:";
	cin>>roll;
	cout<<"enter the subject code:";
	cin>>code;
	cout<<"enter the internal assesment:";
	cin>>ia;
	cout<<"enter the university marks:";
	cin>>um;
}

void marks::displaydata()
{
	cout<<"\n"<<name<<"\t"<<sub<<"\t"<<roll<<"\t"<<code<<"\t"<<ia<<"\t"<<um;
}

int marks::search(int key)
{
	int flag=0;
	if(key==roll)
	flag=1;
	return flag;
	
}
void marks::modify()
{
	int ch,a;
	do
	{
		cout<<"\n 1. name";
		cout<<"\n 2. subject name";
		cout<<"\n 3. student roll no";
		cout<<"\n 4. subject code";
		cout<<"\n 5. internal assesment";
		cout<<"\n 6. university marks";
		cout<<"\n enter ur choice:";
		cin>>ch;
		switch(ch)
		 {
			case 1:cout<<"\n enter new name:";
			      cin>>name;
			      break;
			case 2:cout<<"\n enter new subject name:";
			      cin>>sub;
			      break;
			case 3:cout<<"\n enter new roll no:";
			      cin>>roll;
			      break;
			case 4:cout<<"\n enter new  subject code:";
			      cin>>code;
			      break;
			case 5:cout<<"\n enter new internal asssment:";
			      cin>>ia;
			      break;
			case 6:cout<<"\n enter new university marks:";
			      cin>>um;
			      break;

		 }
		cout<<"do u want to continue??press 1 or 0 :";
		cin>>a;
	}while(a==1);
}
int main()
{
	marks m[20];
	int ch,a,b,n,key,flag;
	int i=0;
	do
	{
		
		
		cout<<"\n 1.getdata \n2.displaydata \n3.delete \n4.search \n5.modify";
		cout<<"\n enter ur choice:";
		cin>>ch;
		switch(ch)
		 {
			case 1: do
			         {
					
					m[i].getdata();
					cout<<"\n do u want to enter record?press 1 or 0:";
				          cin>>a;
					i++;
			         }while(a==1);
				n=i;
				break;
			case 2:cout<<"name"<<"\t"<<"sub"<<"\t"<<"roll"<<"\t"<<"code"<<"\t"<<"ia"<<"\t"<<"um";
				 for(i=0;i<n;i++)
				{
					m[i].displaydata();
				}
				break;
			case 3: cout<<"enter record no:";
			        cin>>key;
			        for(i=key;i<n;i++)
				{
					m[i]=m[i+1];
				}
				cout<<"\n record is deleted";
				n--;
				break;
			case 4:cout<<"\n enter roll no:";
			       cin>>key;
			       for(i=0;i<n;i++)
				{
					flag=m[i].search(key);
					if(flag==1)
					break;
				}
				if(flag==0)
				cout<<"\n record is not present";
				else
				m[i].displaydata();
				break;

			case 5:cout<<"\n enter record no:";
			       cin>>key;
			       m[key].modify();
			       m[key].displaydata();
			       break;
	
				
		 }
		cout<<"\n do u want to continue??press 1 or 0:";
		cin>>b;
	}while(b==1);
	return 0;
}