
#include <iostream>
using namespace std;
#include<stdlib.h>
#include <stdio.h>

template<class T>
class Matrix{
    T m1[3][3],m2[3][3],m3[3][3],m4[3][3],m5[3][3];
public:
    void getMat();
    void operation();
    void calc();
    void disp();
};

template<class T>
void Matrix<T> ::getMat(){
    int i,j;
    cout<<"Enter the 1st 3x3 matrix:";
    for(i=0;i<3;i++){
	for(j=0; j<3;j++){
            cin>>m1[i][j];
        }
    }
    
    cout<<"Enter the 2nd 3x3 matrix:";
    for(i=0;i<3;i++){
	for(j=0; j<3;j++){
            cin>>m2[i][j];
        }
    }
}

template<class T>
void Matrix<T> ::disp(){
    int i,j;
    cout<<"\nAddtion:"<<endl;
	for(i=0;i<3;i++)
	{
		cout<<"|\t";
		for(j=0;j<3;j++)
		{
			cout<<m3[i][j]<<"\t";
		}
		cout<<"|";
		cout<<endl;
	}
	cout<<"\nSubtraction:"<<endl;
	for(i=0;i<3;i++)
	{
		cout<<"|\t";
		for(j=0;j<3;j++)
		{
			cout<<m4[i][j]<<"\t";
		}
		cout<<"|\t";
		cout<<endl;
	}
	cout<<"\nMultiplication:"<<endl;
	for(i=0;i<3;i++)
	{
		cout<<"|\t";
		for(j=0;j<3;j++)
		{
			cout<<m5[i][j]<<"\t";
		}
		cout<<"|\t";
		cout<<endl;
	}	
}

template<class T>
void Matrix<T> ::calc(){
    int i,j,x,y;
    float temp;
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            m3[i][j] = m1[i][j] + m2[i][j];
        }
    }
    
    for(i=0;i<3;i++){
        for(j=0;j<3;j++){
            m4[i][j] = m1[i][j] - m2[i][j];
        }
    }
    
    for(i=0;i<3;i++)
	for(j=0;j<3;j++){
            temp=0;
            for(x=0,y=0;x<3;x++,y++)
		temp+=m1[i][x]*m2[y][j];
            m5[i][j]=temp;
        }

}

template<class T>
void Matrix<T> ::operation(){
    int i;
    char ch;
    do{
        cout<<"\n1.Enter two matrices.\n2.Perform normal arithmetic operatins.";
        cout<<"\n3.Exit.\nEnter your choice:";
        cin>>i;
        switch(i){
            case 1:
                getMat();
                break; 
                
            case 2:
                calc();
                disp();
                break;
                
            case 3:
                exit(0);
        }
        cout<<"\nDo you want to perform operations again:";
        cin>>ch;
    }while(ch=='y');
}

int main() {
    Matrix<int> mat1;
    Matrix<float> mat2;
    int i;
    char ch;
    do{
        cout<<"1.For int operations.\n2.For float operations.\n3.Exit.\nEnter your choice:";
        cin>>i;
        switch(i){
            case 1:
                mat1.operation();
                break;
                
            case 2:
                mat2.operation();
                break;
                
            case 3:
                exit(0);
        }
        cout<<"Do you want to enter again:";
        cin>>ch;
    }while(ch=='y');
    return 0;
}