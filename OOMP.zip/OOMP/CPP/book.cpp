#include<iostream>
#include<string.h>
using namespace std;

class book
{
  char author[30];
  char title[20],publisher[20];
  int price,stock;

  public:
  void getdata();
  void display();
  void search();
};

void book::getdata()
{
  cout<<"enter the author of the book \n";
  cin>>author;
  cout<<"enter the title of the book\n";
  cin>>title;
  cout<<"enter the publication\n";
  cin>>publisher;
  cout<<"enter the price\n";
  cin>>price;
  cout<<"enter the stock";
  cin>>stock;
}

void book::display()
{
 cout<<title<<"\t"<<author<<"\t"<<publisher<<"\t"<<price<<"\t\t"<<stock<<"\n";
}

void book::search()
{  
  char title1[20],author1[30]; int c,cost=1;
  cout<<"enter the title of the book\n";
  cin>>title1;
  cout<<"enter the author of the book\n";
  cin>>author1;
  if(strcmp(title1,title)==0&&strcmp(author1,author)==0)
{
  cout<<"book is available\n";
  cout<<title1<<"\t"<<author1<<"\t"<<publisher<<"\t"<<price<<"\t\t"<<stock<<"\n";
  cout<<"How many copies do you want\n";
  cin>>c;
  if(stock>=c)
{  
  cost=c*price;
  cout<<cost<<"\n";
  stock=stock-c;
}
else
  cout<<"\nCopies not available\n";
  //break;
}
else

  cout<<"book is not available\n";
}




int main()
{ int i,n,ch,p;
  book b[20];
  do
{
  cout<<"MENU\n";
  cout<<"1.Getdata 2.Display 3.Search 4.Exit\n";
  cout<<"enter your choice\n ";
  cin>>ch;

 
  switch(ch)
{
  case 1:
  {
       cout<<"Enter the number of books\n";
       cin>>n;
  
     for(i=0;i<n;i++)
     {
         b[i].getdata();
     }
  }break;
 
   case 2:
   {
     cout<<"Title\tAuthor\tPublication\tPrice\tStock\n";
     for(i=0;i<n;i++)
     {
       b[i].display();
     } 
   }break;
  
  case 3:

  {  cout<<"enter the number of books you want to search\n";
     cin>>p;
     for(i=0;i<p;i++)
     b[i].search();
}
 }
}while(ch!=4);
return 0;
}
  
 