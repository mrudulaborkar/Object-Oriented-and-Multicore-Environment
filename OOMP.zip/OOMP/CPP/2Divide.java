import java.io.IOException;
import java.util.*;

class Excptn extends Exception{
	double num1,num2,num3;
	Scanner s = new Scanner(System.in);
	public void getData() throws IOException{
		s.nextLine();
		System.out.println("Enter 1st double value:");
		if(!s.hasNextDouble()){
			throw new IOException();
		}
		if(s.hasNextDouble()==true){
			num1 = s.nextDouble();
		}
		s.nextLine();
		System.out.println("Enter 2nd double value:");
		if(!s.hasNextDouble()){
			throw new IOException();
		}
		if(s.hasNextDouble()==true){
			num2 = s.nextDouble();
		}
	}
	public void calDiv(){
		if(num2==0){
			throw new ArithmeticException();
		}
		num3=num1/num2;
		System.out.println("Division is:" +num3);
	}
}

public class B8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Excptn e = new Excptn();
		Scanner s = new Scanner(System.in);
		int i;
		char ch = 0;
		do{
			System.out.println("\n\n1.Enter a Double value.\n2.Divide.\n3.Exit.\nEnter your choice:");
			i = s.nextInt();
			switch (i) {
			case 1:
				try {
					e.getData();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					System.out.println("Wrong data type entered..!");
				}				
				break;
				
			case 2:
				try{
					e.calDiv();
				}
				catch(ArithmeticException ae){
					System.out.println("\nThere is divide by zero exception in Division..!");
				}
				break;
				
			case 3:
				System.exit(0);

			default:
				System.out.println("\nInvalid choice..!");
				break;
			}
			System.out.println("\nDo you want to continue:");
			ch = s.next().charAt(0);
		}while(ch=='y');
	}
}