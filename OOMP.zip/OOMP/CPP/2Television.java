import java.util.*;
import java.io.IOException;

class Television extends Exception{
	Scanner s = new Scanner(System.in);
	int price,size,mno;
	public Television() {
		
		price=size=mno=0;
	}
	void getData() throws IOException{
		try{
			System.out.println("Enter Model no.:");
			//price = s.nextInt();
			if(!s.hasNextInt()){
				throw new IOException();
			}
			if(s.hasNextInt()){
				mno = s.nextInt();
				if(mno > 9999){
					throw new IOException();
				}
			}
			System.out.println("Enter it's Size:");
			//price = s.nextInt();
			if(!s.hasNextInt()){
				throw new IOException();
			}
			if(s.hasNextInt()){
				size = s.nextInt();
				if(size < 12 || size > 72){
					throw new IOException();
				}
			}
			System.out.println("Enter it's Price:");
			//price = s.nextInt();
			if(!s.hasNextInt()){
				throw new IOException();
			}
			if(s.hasNextInt()){
				price = s.nextInt();
				if(price > 5000 || price < 0){
					throw new IOException();
				}
			}
		}
		catch(IOException i){
			System.out.println("Invalid data entered..!!");
			price=size=mno=0;
		}
	}
	void disp(){
		System.out.println("Model no:" +mno+ "\nSize:" +size+ "\nPrice:" +price);
	}
}

public class Prog9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		Television t = new Television();
		int i;
		char ch = 0;
		do{
			System.out.println("\n\n1.Enter data.\n2.Display Data.\n3.Exit.\nEnter your choice:");
			i = s.nextInt();
			switch (i) {
			case 1:
				try {
					t.getData();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 2:
				t.disp();
				break;
				
			case 3:
				System.exit(0);

			default:
				System.out.println("\nInvalid choice...!!!");
				break;
			}
			System.out.println("Do you want to enter again:");
			ch = s.next().charAt(0);
		}while(ch=='y');
		s.close();
	}
}
