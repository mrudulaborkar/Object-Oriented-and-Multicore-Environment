import java.util.Scanner;

import javax.swing.JOptionPane;

public class Television {
	private int model_no;
	private int size;
	private int price;
	
	void init()
	{
	model_no=0;
	size=0;
	price=0;
	}
		
	void display()
	{
		System.out.println("Model no\t Screen size\t price\n");
		System.out.println(model_no+"\t"+size+"\t"+price);
	}
	
	public static void main(String[] args) {
		Television t=new Television();
		Scanner sc=new Scanner(System.in);
		try{
			System.out.println("Enter the Model no : ");
			t.model_no=sc.nextInt();
			
			if(t.model_no>9999)
			{
				throw new IllegalArgumentException();
			}
			else
			{
				System.out.println("Enter the Screen size : ");
				t.size=sc.nextInt();
				if(t.size<12||t.size>70)
				{
				throw new ArithmeticException();
				}
				else
				{
					System.out.println("Enter the price : ");
					t.price=sc.nextInt();
					if(t.price<0||t.price>5000)
					{
						{
						throw new NullPointerException();
					
						}
					}	
				
			}
		
			}
	}catch(IllegalArgumentException x)
	
	{
		JOptionPane.showMessageDialog(null," Check model no digits");
		t.init();
		
	}
		catch(ArithmeticException e1)
		
		{
			JOptionPane.showMessageDialog(null," Check screen size");
			t.init();
		//	t.display();
		}
		catch(NullPointerException e1)
		
		{
			JOptionPane.showMessageDialog(null," Check price");
			t.init();
			//t.display();
		}
	
		t.display();
}}
	

	


